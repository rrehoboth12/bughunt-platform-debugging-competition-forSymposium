import { o as __toESM } from "../_runtime.mjs";
import { f as require_jsx_runtime, p as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as formatDuration, o as rankLabel } from "./button-BVpc70Tk.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as getParticipantReview } from "./fns-Dg98ox0C.mjs";
import { t as CoordShell } from "./coord-shell-BE0VDTCN.mjs";
import { t as Badge } from "./badge-W5pHzslX.mjs";
import { r as Route$2 } from "./router-DE-4K4Gv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/participants._id-57A30f5i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReviewPage() {
	const { id } = Route$2.useParams();
	const [data, setData] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getParticipantReview({ data: { id } }).then(setData).catch((err) => setError(err instanceof Error ? err.message : "Could not load review."));
	}, [id]);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoordShell, {
		active: "review",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-danger",
			children: error
		})
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoordShell, {
		active: "review",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading verification record…"
		})
	});
	const p = data.participant;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CoordShell, {
		active: "review",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/coordinator/dashboard",
				className: "text-xs text-muted hover:text-fg",
				children: "Back to results"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-3xl font-semibold",
				children: p.fullName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					p.department,
					" · Year ",
					p.year,
					" · ",
					p.email,
					" · ",
					p.phone,
					" · ",
					p.college
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Rank",
						value: p.rank ? rankLabel(p.rank) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Total",
						value: String(p.totalMarks)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Time",
						value: formatDuration(p.durationMs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Malpractice",
						value: String(p.malpracticeCount)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: p.qMarks.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					variant: "muted",
					children: [
						"Q",
						i + 1,
						" ",
						m
					]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-8",
				children: data.questions.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-[var(--radius-lg)] border border-border p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "font-display text-lg font-semibold",
									children: [
										"Q",
										q.slot,
										" ",
										q.title
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: q.language === "python" ? "python" : "c",
									children: q.language === "python" ? "Python" : "C"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [
										q.marksAwarded,
										"/",
										q.maxMarks
									]
								})
							]
						}),
						q.submittedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-subtle",
							children: ["Submitted ", q.submittedAt]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3 lg:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
									label: "Original buggy code",
									code: q.buggyCode
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
									label: "Participant submitted code",
									code: q.submittedCode
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
									label: "Correct / expected code",
									code: q.correctCode
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-sm font-medium",
							children: "Error-level marking"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-left text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "text-[11px] uppercase tracking-[0.12em] text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-1 pr-3",
											children: "Type"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-1 pr-3",
											children: "Description"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-1 pr-3",
											children: "Expected"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-1 pr-3",
											children: "Fixed"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-1",
											children: "Marks"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: q.errors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 pr-3",
											children: e.errorType
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 pr-3",
											children: e.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 pr-3 font-mono text-xs",
											children: e.expectedCorrection
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 pr-3",
											children: e.fixed ? "Yes" : "No"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-2 tabular-nums",
											children: [
												e.awarded,
												"/",
												e.marks
											]
										})
									]
								}, e.id)) })]
							})
						}),
						q.testResults.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 text-xs text-muted",
							children: [
								"Tests:",
								" ",
								q.testResults.map((t) => t.passed ? "PASS" : "FAIL").join(" · ")
							]
						}) : null,
						q.compileOutput ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-2 overflow-auto font-mono text-[11px] text-muted",
							children: q.compileOutput
						}) : null,
						q.runtimeOutput ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-2 overflow-auto font-mono text-[11px] text-muted",
							children: q.runtimeOutput
						}) : null
					]
				}, q.questionId))
			}),
			data.malpractice.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Malpractice log"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2 text-sm",
					children: data.malpractice.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-[var(--radius-sm)] border border-border px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted",
								children: m.occurredAt
							}),
							" · ",
							m.violationType,
							m.questionSlot ? ` · Q${m.questionSlot}` : "",
							" · count ",
							m.violationCount
						]
					}, m.id))
				})]
			}) : null
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[var(--radius-md)] border border-border bg-bg-elevated p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[11px] uppercase tracking-[0.14em] text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-display text-xl font-semibold tabular-nums",
			children: value
		})]
	});
}
function CodeBlock({ label, code }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-1 text-[11px] uppercase tracking-[0.14em] text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
		className: "max-h-72 overflow-auto rounded-[var(--radius-sm)] border border-border bg-bg p-3 font-mono text-[11px] leading-relaxed",
		children: code
	})] });
}
//#endregion
export { ReviewPage as component };
