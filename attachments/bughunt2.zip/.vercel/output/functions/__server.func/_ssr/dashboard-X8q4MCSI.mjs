import { o as __toESM } from "../_runtime.mjs";
import { f as require_jsx_runtime, p as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as formatDuration, o as rankLabel, r as cn, t as Button } from "./button-BVpc70Tk.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as exportCsv, c as getCompetition, m as listCoordinatorParticipants, o as exportDetailed } from "./fns-Dg98ox0C.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as CoordShell } from "./coord-shell-BE0VDTCN.mjs";
import { t as Badge } from "./badge-W5pHzslX.mjs";
import { c as Plus, d as Download, u as Pencil } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-X8q4MCSI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DashboardPage() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [comp, setComp] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		Promise.all([listCoordinatorParticipants(), getCompetition()]).then(([people, c]) => {
			setRows(people);
			setComp(c);
		});
	}, []);
	async function downloadCsv() {
		try {
			const file = await exportCsv();
			triggerDownload(file.filename, file.csv, "text/csv");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Export failed.");
		}
	}
	async function downloadDetailed() {
		try {
			const file = await exportDetailed();
			triggerDownload(file.filename, file.text, "text/plain");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Export failed.");
		}
	}
	const ranked = [...rows].sort((a, b) => (a.rank ?? 9999) - (b.rank ?? 9999));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CoordShell, {
		active: "results",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "Results"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: comp ? `Competition ${comp.status} · ${comp.pythonCount} Python + ${comp.cCount} C selected` : "Loading…"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void downloadCsv(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), "Results CSV"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void downloadDetailed(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), "Answer report"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3 rounded-[var(--radius-lg)] border border-primary/30 bg-primary/10 p-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Question bank & answer keys"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: ["Update buggy programs, paste the correct answers, and set marks for each error.", comp ? ` Current mix: ${comp.pythonCount} Python + ${comp.cCount} C selected.` : null]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/coordinator/questions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" }), "Manage questions"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/coordinator/questions/$id",
							params: { id: "new" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Add question"]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 overflow-x-auto rounded-[var(--radius-lg)] border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[960px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-bg-subtle text-[11px] uppercase tracking-[0.12em] text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
							"Rank",
							"Name",
							"Dept",
							"Year",
							"Email",
							"Phone",
							"College",
							"Q1",
							"Q2",
							"Q3",
							"Q4",
							"Q5",
							"Q6",
							"Total",
							"Time",
							"Status",
							"Malpractice"
						].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 font-medium",
							children: h
						}, h)) })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ranked.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 17,
						className: "px-3 py-8 text-center text-muted",
						children: "No participants yet."
					}) }) : ranked.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: cn("border-t border-border", r.rank === 1 || r.rank === 2 || r.rank === 3 ? "bg-primary/10" : "bg-bg-elevated"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 font-mono",
								children: r.rank ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/coordinator/participants/$id",
									params: { id: r.id },
									className: "text-primary hover:underline",
									children: rankLabel(r.rank)
								}) : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/coordinator/participants/$id",
									params: { id: r.id },
									className: "hover:underline",
									children: r.fullName
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-muted",
								children: r.department
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-muted",
								children: r.year
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-muted",
								children: r.email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-muted",
								children: r.phone
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "max-w-36 truncate px-3 py-2 text-muted",
								children: r.college
							}),
							r.qMarks.slice(0, 6).map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: m
							}, i)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 font-medium tabular-nums",
								children: r.totalMarks
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 font-mono text-xs",
								children: formatDuration(r.durationMs)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: r.status === "submitted" ? "success" : r.status === "terminated" ? "danger" : r.status === "in_progress" ? "warn" : "muted",
									children: r.status.replace("_", " ")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: r.malpracticeCount
							})
						]
					}, r.id)) })]
				})
			})
		]
	});
}
function triggerDownload(filename, content, type) {
	const blob = new Blob([content], { type });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
//#endregion
export { DashboardPage as component };
