import { o as __toESM } from "../_runtime.mjs";
import { f as require_jsx_runtime, p as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { M as EditorView } from "../_libs/@codemirror/autocomplete+[...].mjs";
import { t as cpp } from "../_libs/@codemirror/lang-cpp+[...].mjs";
import { t as python } from "../_libs/@codemirror/lang-python+[...].mjs";
import { t as ReactCodeMirror } from "../_libs/uiw__react-codemirror.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/code-editor-DN4wJ3xk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var theme = EditorView.theme({
	"&": {
		backgroundColor: "#0b0d12",
		color: "#e8eaed",
		fontSize: "13.5px",
		height: "100%"
	},
	".cm-content": {
		fontFamily: "\"IBM Plex Mono\", ui-monospace, Menlo, Consolas, monospace",
		caretColor: "#14b8a6",
		padding: "12px 0"
	},
	".cm-gutters": {
		backgroundColor: "#0b0d12",
		color: "#5c6370",
		border: "none"
	},
	".cm-activeLine": { backgroundColor: "rgba(20, 184, 166, 0.06)" },
	".cm-activeLineGutter": {
		backgroundColor: "transparent",
		color: "#14b8a6"
	},
	".cm-selectionBackground": { backgroundColor: "rgba(20, 184, 166, 0.28) !important" },
	"&.cm-focused .cm-selectionBackground": { backgroundColor: "rgba(20, 184, 166, 0.28) !important" },
	".cm-cursor": { borderLeftColor: "#14b8a6" },
	".cm-scroller": { overflow: "auto" }
}, { dark: true });
function CodeEditor({ language, value, onChange, readOnly }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: "h-full min-h-64 w-full resize-none bg-bg p-3 font-mono text-sm text-fg outline-none",
		value,
		onChange: (e) => onChange(e.target.value),
		readOnly,
		spellCheck: false
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactCodeMirror, {
		value,
		height: "100%",
		theme,
		extensions: [language === "python" ? python() : cpp(), EditorView.lineWrapping],
		onChange,
		readOnly,
		basicSetup: {
			lineNumbers: true,
			foldGutter: false,
			highlightActiveLine: true,
			autocompletion: false,
			searchKeymap: false
		}
	});
}
//#endregion
export { CodeEditor as t };
