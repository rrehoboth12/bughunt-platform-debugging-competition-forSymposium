import { f as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-BVpc70Tk.mjs";
import { n as GridBackdrop, t as BrandMark } from "./brand-EOlDjbgj.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shield, m as Clock, p as CodeXml, t as Trophy, y as ArrowRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DlBRHkKH.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-dvh overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridBackdrop, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-dvh max-w-5xl flex-col px-5 py-6 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/coordinator",
						className: "text-xs uppercase tracking-[0.16em] text-muted hover:text-fg",
						children: "Coordinator"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-1 flex-col justify-center py-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.28em] text-muted",
							children: "Arunachala College of Engineering"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Artificial Intelligence and Data Science"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-6 font-display text-5xl font-semibold leading-[0.95] tracking-tight sm:text-7xl",
							children: "MIRAI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 inline-flex w-fit items-center gap-3 rounded-[var(--radius-md)] border border-primary/30 bg-primary/10 px-4 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xl font-semibold text-primary sm:text-2xl",
									children: "BUG HUNT"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hidden h-4 w-px bg-primary/40 sm:block" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden font-mono text-xs text-primary sm:inline",
									children: "3 Python · 3 C · 45:00"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-lg text-muted",
							children: "Find the Bug. Fix the Code. Beat the Clock."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-sm text-subtle",
							children: "A live debugging competition. Six programs. Positive marking for every error you correct. Ranked by score, then time."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/register",
									children: ["Enter competition", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/coordinator",
									children: "Coordinator access"
								})
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid gap-3 pb-8 sm:grid-cols-4",
					children: [
						{
							icon: CodeXml,
							label: "Six programs",
							detail: "3 Python, 3 C"
						},
						{
							icon: Clock,
							label: "One timer",
							detail: "Starts on START TEST"
						},
						{
							icon: Shield,
							label: "No negative marks",
							detail: "Fixes only add score"
						},
						{
							icon: Trophy,
							label: "Live ranking",
							detail: "Score, then time"
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-[var(--radius-lg)] border border-border bg-bg-elevated/80 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 text-sm font-medium",
								children: item.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: item.detail
							})
						]
					}, item.label))
				})
			]
		})]
	});
}
//#endregion
export { Home as component };
