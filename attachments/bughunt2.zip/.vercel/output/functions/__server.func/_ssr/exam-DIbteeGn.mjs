import { o as __toESM } from "../_runtime.mjs";
import { a as Overlay2, c as Title2, f as require_jsx_runtime, i as Description2, n as Cancel, o as Portal2, p as require_react, r as Content2, s as Root2, t as Action } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as formatClock, n as buttonVariants, r as cn, t as Button } from "./button-BVpc70Tk.mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as submitAnswer, S as saveCode, g as logMalpractice, l as getExamState, s as finishExam, w as setCurrentQuestion, x as runCode } from "./fns-Dg98ox0C.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Badge } from "./badge-W5pHzslX.mjs";
import { _ as ChevronLeft, g as ChevronRight, i as Square, l as Play, o as Send, s as RotateCcw } from "../_libs/lucide-react.mjs";
import { t as CodeEditor } from "./code-editor-DN4wJ3xk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exam-DIbteeGn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	ref,
	className: cn("fixed inset-0 z-50 bg-bg/80", className),
	...props
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-6", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-2", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("font-display text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
function statusLabel(status) {
	if (status === "correct") return "Correct";
	if (status === "partial") return "Partially correct";
	if (status === "attempted") return "Attempted";
	return "Not attempted";
}
function ExamPage() {
	const navigate = useNavigate();
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [questions, setQuestions] = (0, import_react.useState)([]);
	const [answers, setAnswers] = (0, import_react.useState)([]);
	const [slot, setSlot] = (0, import_react.useState)(1);
	const [codes, setCodes] = (0, import_react.useState)({});
	const [remaining, setRemaining] = (0, import_react.useState)(0);
	const [output, setOutput] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [finishOpen, setFinishOpen] = (0, import_react.useState)(false);
	const [terminated, setTerminated] = (0, import_react.useState)(false);
	const [fsHeld, setFsHeld] = (0, import_react.useState)(false);
	const armed = (0, import_react.useRef)(false);
	const slotRef = (0, import_react.useRef)(1);
	const lastLog = (0, import_react.useRef)({});
	const current = questions.find((q) => q.slot === slot) ?? questions[0];
	const currentAnswer = answers.find((a) => a.questionId === current?.id);
	const load = (0, import_react.useCallback)(async () => {
		try {
			const state = await getExamState();
			if (state.participant.status === "terminated") {
				setTerminated(true);
				return;
			}
			if (state.participant.status === "submitted") {
				await navigate({ to: "/result" });
				return;
			}
			setQuestions(state.questions);
			setAnswers(state.answers);
			setRemaining(Math.ceil(state.remainingMs / 1e3));
			setCodes((prev) => {
				const next = { ...prev };
				for (const a of state.answers) if (next[a.questionId] == null) next[a.questionId] = a.currentCode;
				return next;
			});
			setSlot(state.participant.currentQuestion || 1);
			slotRef.current = state.participant.currentQuestion || 1;
		} catch {
			await navigate({ to: "/register" });
		} finally {
			setLoading(false);
		}
	}, [navigate]);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	(0, import_react.useEffect)(() => {
		const t = window.setTimeout(() => {
			armed.current = true;
		}, 2500);
		return () => window.clearTimeout(t);
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			setRemaining((s) => {
				if (s <= 1) {
					finishExam().then(() => navigate({ to: "/result" }));
					return 0;
				}
				return s - 1;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [navigate]);
	const report = (0, import_react.useCallback)(async (violationType) => {
		if (!armed.current) return;
		const now = Date.now();
		if ((lastLog.current[violationType] ?? 0) > now - 2e3) return;
		lastLog.current[violationType] = now;
		try {
			if ((await logMalpractice({ data: {
				violationType,
				questionSlot: slotRef.current
			} })).terminated) setTerminated(true);
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		const onVis = () => {
			if (document.hidden) report("visibility");
		};
		const onBlur = () => void report("blur");
		const onFs = () => {
			if (!document.fullscreenElement && fsHeld) report("fullscreen_exit");
			setFsHeld(Boolean(document.fullscreenElement));
		};
		const block = (e, type) => {
			e.preventDefault();
			report(type);
		};
		const onKey = (e) => {
			const key = e.key.toLowerCase();
			if (e.key === "F5" || (e.ctrlKey || e.metaKey) && key === "r") {
				e.preventDefault();
				report("refresh");
			}
			if ((e.ctrlKey || e.metaKey) && (key === "c" || key === "x" || key === "v")) {
				e.preventDefault();
				report(key === "c" ? "copy" : key === "x" ? "cut" : "paste");
			}
			if (e.key === "PrintScreen") {
				e.preventDefault();
				report("print_screen");
			}
		};
		const onCopy = (e) => block(e, "copy");
		const onCut = (e) => block(e, "cut");
		const onPaste = (e) => block(e, "paste");
		const onContext = (e) => e.preventDefault();
		const onLeave = (e) => {
			e.preventDefault();
			e.returnValue = "";
			report("navigation");
		};
		document.addEventListener("visibilitychange", onVis);
		window.addEventListener("blur", onBlur);
		document.addEventListener("fullscreenchange", onFs);
		document.addEventListener("copy", onCopy);
		document.addEventListener("cut", onCut);
		document.addEventListener("paste", onPaste);
		document.addEventListener("keydown", onKey);
		document.addEventListener("contextmenu", onContext);
		window.addEventListener("beforeunload", onLeave);
		return () => {
			document.removeEventListener("visibilitychange", onVis);
			window.removeEventListener("blur", onBlur);
			document.removeEventListener("fullscreenchange", onFs);
			document.removeEventListener("copy", onCopy);
			document.removeEventListener("cut", onCut);
			document.removeEventListener("paste", onPaste);
			document.removeEventListener("keydown", onKey);
			document.removeEventListener("contextmenu", onContext);
			window.removeEventListener("beforeunload", onLeave);
		};
	}, [fsHeld, report]);
	async function go(nextSlot) {
		if (!current) return;
		const code = codes[current.id] ?? "";
		saveCode({ data: {
			questionId: current.id,
			code
		} });
		setSlot(nextSlot);
		slotRef.current = nextSlot;
		setCurrentQuestion({ data: { slot: nextSlot } });
	}
	async function onRun() {
		if (!current) return;
		setBusy("run");
		try {
			const res = await runCode({ data: {
				questionId: current.id,
				code: codes[current.id] ?? ""
			} });
			const lines = [
				res.error ? `Sandbox: ${res.error}` : null,
				res.compileOutput ? `Compile:\n${res.compileOutput}` : null,
				res.runtimeOutput ? `Output:\n${res.runtimeOutput}` : null,
				...res.tests.map((t) => `Test ${t.id.slice(-4)}: ${t.passed ? "PASS" : "FAIL"}${t.stderr ? `\n${t.stderr}` : ""}`)
			].filter(Boolean);
			setOutput(lines.join("\n\n") || "No output.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Run failed.");
		} finally {
			setBusy(null);
		}
	}
	async function onSubmit() {
		if (!current) return;
		setBusy("submit");
		try {
			const res = await submitAnswer({ data: {
				questionId: current.id,
				code: codes[current.id] ?? ""
			} });
			toast.success(res.message);
			setAnswers((prev) => prev.map((a) => a.questionId === current.id ? {
				...a,
				bestMarks: res.bestMarks,
				status: res.status
			} : a));
			const exec = res.execution;
			setOutput([
				exec.error ? `Sandbox: ${exec.error}` : null,
				exec.compileOutput ? `Compile:\n${exec.compileOutput}` : null,
				exec.runtimeOutput ? `Output:\n${exec.runtimeOutput}` : null,
				`This attempt: ${res.marksAwarded}  ·  Best: ${res.bestMarks}/${res.maxMarks}  ·  Fixed ${res.fixedCount}, remaining ${res.unfixedCount}`
			].filter(Boolean).join("\n\n"));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Submit failed.");
		} finally {
			setBusy(null);
		}
	}
	function resetCode() {
		if (!current) return;
		setCodes((prev) => ({
			...prev,
			[current.id]: current.buggyCode
		}));
	}
	async function confirmFinish() {
		try {
			if (current) await saveCode({ data: {
				questionId: current.id,
				code: codes[current.id] ?? ""
			} });
			await finishExam();
			await navigate({ to: "/result" });
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not finish.");
		}
	}
	const lowTime = remaining <= 60;
	const code = current ? codes[current.id] ?? "" : "";
	const nav = (0, import_react.useMemo)(() => questions, [questions]);
	if (terminated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-bg px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs uppercase tracking-[0.2em] text-danger",
					children: "Test terminated"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-3xl font-semibold",
					children: "A prohibited activity was detected"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Your examination has been automatically submitted."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6",
					onClick: () => void navigate({ to: "/result" }),
					children: "View result"
				})
			]
		})
	});
	if (loading || !current) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center text-muted",
		children: "Loading examination…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex shrink-0 items-center gap-3 border-b border-border px-3 py-2 sm:px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-sm font-semibold",
						children: "MIRAI — BUG HUNT"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] uppercase tracking-[0.16em] text-muted",
						children: [
							"Question ",
							current.slot,
							" / 6"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("rounded-[var(--radius-sm)] border px-3 py-1 font-mono text-lg tabular-nums", lowTime ? "border-danger/40 bg-danger/10 text-danger" : "border-border bg-bg-elevated text-fg"),
						children: formatClock(remaining)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setFinishOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-3.5" }), "Finish"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex shrink-0 gap-1 overflow-x-auto border-b border-border px-3 py-2",
				children: nav.map((q) => {
					const a = answers.find((x) => x.questionId === q.id);
					const active = q.slot === slot;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void go(q.slot),
						className: cn("min-w-16 rounded-[var(--radius-sm)] border px-3 py-2 text-left", active ? "border-primary bg-primary/10" : "border-border bg-bg-elevated"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-xs",
							children: ["Q", q.slot]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] text-muted",
							children: statusLabel(a?.status ?? "not_attempted")
						})]
					}, q.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-0 flex-1 lg:grid-cols-[minmax(16rem,22rem)_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "min-h-0 overflow-auto border-b border-border p-4 lg:border-b-0 lg:border-r",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: current.language === "python" ? "python" : "c",
								children: current.language === "python" ? "Python" : "C"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted",
								children: [
									"Max ",
									current.maxMarks,
									" · Best ",
									currentAnswer?.bestMarks ?? 0
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-lg font-semibold leading-snug",
							children: current.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: current.description
						}),
						current.visibleTests.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] uppercase tracking-[0.16em] text-muted",
								children: "Visible tests"
							}), current.visibleTests.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-2 overflow-auto rounded-[var(--radius-sm)] border border-border bg-bg-subtle p-3 font-mono text-[11px] text-fg",
								children: t.expectedStdout
							}, t.id))]
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-0 flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-0 flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
								language: current.language,
								value: code,
								onChange: (v) => setCodes((prev) => ({
									...prev,
									[current.id]: v
								}))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 flex-wrap gap-2 border-t border-border p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => void onRun(),
									disabled: !!busy,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5" }), busy === "run" ? "Running…" : "Run code"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => void onSubmit(),
									disabled: !!busy,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-3.5" }), busy === "submit" ? "Submitting…" : "Submit answer"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									onClick: resetCode,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "Reset code"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "ml-auto flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "ghost",
										disabled: slot <= 1,
										onClick: () => void go(slot - 1),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-3.5" }), "Previous"]
									}), slot < 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => void go(slot + 1),
										children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5" })]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setFinishOpen(true),
										children: "Finish test"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-32 shrink-0 overflow-auto border-t border-border bg-bg-elevated p-3 font-mono text-xs whitespace-pre-wrap text-muted",
							children: output || "Run or submit to see compiler / runtime output."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: finishOpen,
				onOpenChange: setFinishOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Finish BUG HUNT?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "Are you sure you want to finish BUG HUNT? Your answers cannot be changed after final submission." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Continue exam" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: () => void confirmFinish(),
					children: "Finish test"
				})] })] })
			})
		]
	});
}
//#endregion
export { ExamPage as component };
