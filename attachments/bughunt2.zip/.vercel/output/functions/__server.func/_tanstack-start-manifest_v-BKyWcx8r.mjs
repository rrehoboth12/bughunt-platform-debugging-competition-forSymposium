//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BKyWcx8r.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/confirm",
			"/exam",
			"/register",
			"/result",
			"/rules",
			"/coordinator/dashboard",
			"/coordinator/questions",
			"/coordinator/settings",
			"/coordinator/",
			"/coordinator/participants/$id"
		],
		preloads: [
			"/assets/index-yh2P3qdO.js",
			"/assets/useRouter-Dpb7RwMI.js",
			"/assets/createClientRpc-DYgQtVvO.js",
			"/assets/link-DoXit5rd.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/matchContext-DN9gHYo-.js",
			"/assets/useStore-CTwjHYef.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-yh2P3qdO.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CkJZRFR3.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/brand-BMkOke03.js"
		]
	},
	"/confirm": {
		filePath: "/workspace/src/routes/confirm.tsx",
		children: void 0,
		preloads: [
			"/assets/confirm-Byoo8Sil.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/brand-BMkOke03.js",
			"/assets/card-DxM8kCVv.js"
		]
	},
	"/exam": {
		filePath: "/workspace/src/routes/exam.tsx",
		children: void 0,
		preloads: [
			"/assets/exam-CDD2sccg.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/badge-CHWoutOA.js",
			"/assets/dist-BSYWE6v3.js",
			"/assets/code-editor-Dvpm2NTV.js"
		]
	},
	"/register": {
		filePath: "/workspace/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-CIAEMlky.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/brand-BMkOke03.js",
			"/assets/card-DxM8kCVv.js",
			"/assets/label-BieFpBOe.js"
		]
	},
	"/result": {
		filePath: "/workspace/src/routes/result.tsx",
		children: void 0,
		preloads: [
			"/assets/result-BvK7b_uB.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/brand-BMkOke03.js",
			"/assets/card-DxM8kCVv.js",
			"/assets/badge-CHWoutOA.js"
		]
	},
	"/rules": {
		filePath: "/workspace/src/routes/rules.tsx",
		children: void 0,
		preloads: [
			"/assets/rules-CatWtHR1.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/brand-BMkOke03.js",
			"/assets/card-DxM8kCVv.js"
		]
	},
	"/coordinator/dashboard": {
		filePath: "/workspace/src/routes/coordinator/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-DW0q5Tfu.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/pencil-DkQtTcqZ.js",
			"/assets/plus-DvMjlOGW.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/coord-shell-35w4KckG.js",
			"/assets/badge-CHWoutOA.js"
		]
	},
	"/coordinator/questions": {
		filePath: "/workspace/src/routes/coordinator/questions.tsx",
		children: ["/coordinator/questions/$id", "/coordinator/questions/"],
		preloads: ["/assets/questions-BRfLaZUY.js"]
	},
	"/coordinator/settings": {
		filePath: "/workspace/src/routes/coordinator/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CtYcUFoS.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/coord-shell-35w4KckG.js",
			"/assets/label-BieFpBOe.js"
		]
	},
	"/coordinator/": {
		filePath: "/workspace/src/routes/coordinator/index.tsx",
		children: void 0,
		preloads: [
			"/assets/coordinator-COHOIdeT.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/brand-BMkOke03.js",
			"/assets/card-DxM8kCVv.js",
			"/assets/label-BieFpBOe.js"
		]
	},
	"/coordinator/participants/$id": {
		filePath: "/workspace/src/routes/coordinator/participants.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/participants._id-BJI7oCUU.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/coord-shell-35w4KckG.js",
			"/assets/badge-CHWoutOA.js"
		]
	},
	"/coordinator/questions/$id": {
		filePath: "/workspace/src/routes/coordinator/questions.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/questions._id-CypZcoZG.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/plus-DvMjlOGW.js",
			"/assets/scoring-DedX6QOJ.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/coord-shell-35w4KckG.js",
			"/assets/label-BieFpBOe.js",
			"/assets/code-editor-Dvpm2NTV.js"
		]
	},
	"/coordinator/questions/": {
		filePath: "/workspace/src/routes/coordinator/questions.index.tsx",
		children: void 0,
		preloads: [
			"/assets/questions.index-Chj4-qz_.js",
			"/assets/fns-D88MjlF_.js",
			"/assets/pencil-DkQtTcqZ.js",
			"/assets/plus-DvMjlOGW.js",
			"/assets/scoring-DedX6QOJ.js",
			"/assets/button-ZsR6ku_X.js",
			"/assets/coord-shell-35w4KckG.js",
			"/assets/badge-CHWoutOA.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
