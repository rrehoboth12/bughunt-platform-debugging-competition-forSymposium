import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CoordShell } from "@/components/coord-shell";
import { Badge } from "@/components/ui/badge";
import { getParticipantReview } from "@/lib/bughunt/fns";
import type { ParticipantReview } from "@/lib/bughunt/types";
import { formatDuration, rankLabel } from "@/lib/utils";

export const Route = createFileRoute("/coordinator/participants/$id")({
  component: ReviewPage,
});

function ReviewPage() {
  const { id } = Route.useParams();
  const [data, setData] = useState<ParticipantReview | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void getParticipantReview({ data: { id } })
      .then(setData)
      .catch((err: unknown) =>
        setError(err instanceof Error ? err.message : "Could not load review."),
      );
  }, [id]);

  if (error) {
    return (
      <CoordShell active="review">
        <p className="text-danger">{error}</p>
      </CoordShell>
    );
  }
  if (!data) {
    return (
      <CoordShell active="review">
        <p className="text-muted">Loading verification record…</p>
      </CoordShell>
    );
  }

  const p = data.participant;

  return (
    <CoordShell active="review">
      <Link to="/coordinator/dashboard" className="text-xs text-muted hover:text-fg">
        Back to results
      </Link>
      <h1 className="mt-3 font-display text-3xl font-semibold">{p.fullName}</h1>
      <p className="text-sm text-muted">
        {p.department} · Year {p.year} · {p.email} · {p.phone} · {p.college}
      </p>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Rank" value={p.rank ? rankLabel(p.rank) : "—"} />
        <Stat label="Total" value={String(p.totalMarks)} />
        <Stat label="Time" value={formatDuration(p.durationMs)} />
        <Stat label="Malpractice" value={String(p.malpracticeCount)} />
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {p.qMarks.map((m, i) => (
          <Badge key={i} variant="muted">
            Q{i + 1} {m}
          </Badge>
        ))}
      </div>

      <div className="mt-8 grid gap-8">
        {data.questions.map((q) => (
          <section key={q.questionId} className="rounded-[var(--radius-lg)] border border-border p-4">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-lg font-semibold">
                Q{q.slot} {q.title}
              </h2>
              <Badge variant={q.language === "python" ? "python" : "c"}>
                {q.language === "python" ? "Python" : "C"}
              </Badge>
              <span className="text-sm text-muted">
                {q.marksAwarded}/{q.maxMarks}
              </span>
            </div>
            {q.submittedAt ? (
              <p className="mt-1 text-xs text-subtle">Submitted {q.submittedAt}</p>
            ) : null}

            <div className="mt-4 grid gap-3 lg:grid-cols-3">
              <CodeBlock label="Original buggy code" code={q.buggyCode} />
              <CodeBlock label="Participant submitted code" code={q.submittedCode} />
              <CodeBlock label="Correct / expected code" code={q.correctCode} />
            </div>

            <h3 className="mt-4 text-sm font-medium">Error-level marking</h3>
            <div className="mt-2 overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="text-[11px] uppercase tracking-[0.12em] text-muted">
                  <tr>
                    <th className="py-1 pr-3">Type</th>
                    <th className="py-1 pr-3">Description</th>
                    <th className="py-1 pr-3">Expected</th>
                    <th className="py-1 pr-3">Fixed</th>
                    <th className="py-1">Marks</th>
                  </tr>
                </thead>
                <tbody>
                  {q.errors.map((e) => (
                    <tr key={e.id} className="border-t border-border">
                      <td className="py-2 pr-3">{e.errorType}</td>
                      <td className="py-2 pr-3">{e.description}</td>
                      <td className="py-2 pr-3 font-mono text-xs">{e.expectedCorrection}</td>
                      <td className="py-2 pr-3">{e.fixed ? "Yes" : "No"}</td>
                      <td className="py-2 tabular-nums">
                        {e.awarded}/{e.marks}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {q.testResults.length > 0 ? (
              <div className="mt-3 text-xs text-muted">
                Tests:{" "}
                {q.testResults.map((t) => (t.passed ? "PASS" : "FAIL")).join(" · ")}
              </div>
            ) : null}
            {q.compileOutput ? (
              <pre className="mt-2 overflow-auto font-mono text-[11px] text-muted">
                {q.compileOutput}
              </pre>
            ) : null}
            {q.runtimeOutput ? (
              <pre className="mt-2 overflow-auto font-mono text-[11px] text-muted">
                {q.runtimeOutput}
              </pre>
            ) : null}
          </section>
        ))}
      </div>

      {data.malpractice.length > 0 ? (
        <section className="mt-8">
          <h2 className="font-display text-lg font-semibold">Malpractice log</h2>
          <ul className="mt-3 grid gap-2 text-sm">
            {data.malpractice.map((m) => (
              <li key={m.id} className="rounded-[var(--radius-sm)] border border-border px-3 py-2">
                <span className="font-mono text-xs text-muted">{m.occurredAt}</span>
                {" · "}
                {m.violationType}
                {m.questionSlot ? ` · Q${m.questionSlot}` : ""}
                {" · count "}
                {m.violationCount}
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </CoordShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[var(--radius-md)] border border-border bg-bg-elevated p-3">
      <div className="text-[11px] uppercase tracking-[0.14em] text-muted">{label}</div>
      <div className="mt-1 font-display text-xl font-semibold tabular-nums">{value}</div>
    </div>
  );
}

function CodeBlock({ label, code }: { label: string; code: string }) {
  return (
    <div>
      <div className="mb-1 text-[11px] uppercase tracking-[0.14em] text-muted">{label}</div>
      <pre className="max-h-72 overflow-auto rounded-[var(--radius-sm)] border border-border bg-bg p-3 font-mono text-[11px] leading-relaxed">
        {code}
      </pre>
    </div>
  );
}
